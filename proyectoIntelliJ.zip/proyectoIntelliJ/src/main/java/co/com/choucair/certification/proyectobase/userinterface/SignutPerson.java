package co.com.choucair.certification.proyectobase.userinterface;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class SignutPerson extends PageObject {
    public static final Target join_Today_button=Target.the("Button for start account setup").located(By.xpath("//a[@class='unauthenticated-nav-bar__sign-up']//[comtains(text(),'Join Today')]"));
    public static final Target Input_FirstName = Target.the("Where do we write first name").located(By.id("firsName"));
    public static final Target Input_lastName = Target.the("Where do we write last name").located(By.id("lastName"));
    public static final Target Input_Email = Target.the("Where do we write email").located(By.id("email"));
    public static final Target Input_Month = Target.the("Where do we selected month").located(By.id("birthMonth"));
    public static final Target Input_Day = Target.the("Where do we selected birth day ").located(By.id("birthDay"));
    public static final Target Input_year = Target.the("Where do we selected birth year ").located(By.id("birthYear"));
    public static final Target NextLocation=Target.the("Button for next Page").located(By.xpath("//a[@class='btn btn-blue']//span[comtains(text(),'Next: Location')]"));
}

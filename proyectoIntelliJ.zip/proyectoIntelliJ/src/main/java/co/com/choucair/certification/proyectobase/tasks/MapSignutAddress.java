package co.com.choucair.certification.proyectobase.tasks;

import co.com.choucair.certification.proyectobase.userinterface.SignutAddress;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static co.com.choucair.certification.proyectobase.userinterface.SignutAddress.*;

public class MapSignutAddress implements Task {

    private String city,state,zip,country;

    public MapSignutAddress(String city) {
        this.city = city;
    }
    public static MapSignutAddress the (String city){return Tasks.instrumented(MapSignutAddress.class,city);}

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(Input_City),
                Click.on(Input_state),
                Enter.theValue(zip).into(Input_Zip),
                Click.on(Input_Country)
        );
    }
}

package co.com.choucair.certification.proyectobase.userinterface;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class SignutAddress extends PageObject {
    public static final Target Input_City = Target.the("Where do we select city ").located(By.id("city"));
    public static final Target Input_state = Target.the("Where do we select state ").located(By.id("zip"));
    public static final Target Input_Zip = Target.the("Where do we write zip ").located(By.id("zip"));
    public static final Target Input_Country = Target.the("Where do we select country ").located(By.id("countryId"));
    public static final Target NextLocation=Target.the("Button for next Page").located(By.xpath("//a[@class='btn btn-blue pull-right']//span[comtains(text(),'Next: Devices')]"));
}

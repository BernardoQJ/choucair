package co.com.choucair.certification.proyectobase.model;

import org.apache.xpath.objects.XString;

public class signupPersonData {
    private String firtName;
    private String lastName;
    private String emailAddress;
    private String month;
    private int day;
    private int year;
    private String city;
    private String state;
    private String zip;
    private String country;
    private String computer;
    private String computerVersion;
    private String computerLenguaje;
    private String movilDevice;
    private String movilModel;
    private String movilSystem;
    private String password;
    private String passwordConfirm;

    public void setFirtName(String firtName) {this.firtName = firtName; }
    public void setLastName(String lastName){this.lastName = lastName;}
    public void setEmailAddress(String emailAddress){this.emailAddress=emailAddress;}
    public String getMonth(){return month;}
    public int getDay(){return day;}
    public int getYear(){return year;}
    public String getCity(){return city;}
    public String getState(){return state;}
    public void setZip(String zip){this.zip= zip;}
    public String getCountry(){return country;}
    public void setComputer(String computer){this.computer= computer;}
    public void setComputerVersion(String computerVersion){this.computerVersion= computerVersion;}
    public void setComputerLenguaje(String computerLenguaje){this.computerLenguaje= computerLenguaje;}
    public void setMovilDevice(String movilDevice){this.movilDevice= movilDevice;}
    public void setMovilModel(String movilModel){this.movilModel= movilModel;}
    public void setMovilSystem(String movilSystem){this.movilSystem= movilSystem;}
    public void setPassword(String password){this.password=password;}
    public void setpasswordConfirm(String passwordConfirm){this.passwordConfirm=passwordConfirm;}
}

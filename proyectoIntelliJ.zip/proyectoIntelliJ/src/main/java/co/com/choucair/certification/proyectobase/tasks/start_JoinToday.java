package co.com.choucair.certification.proyectobase.tasks;

import co.com.choucair.certification.proyectobase.userinterface.SignutPerson;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static co.com.choucair.certification.proyectobase.userinterface.SignutPerson.*;

public class start_JoinToday implements Task {
    private String FirtName,lastName,emailAddress,month,day,year;

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(SignutPerson.join_Today_button),
                Enter.theValue(FirtName).into(SignutPerson.Input_FirstName),
                Enter.theValue(lastName).into(SignutPerson.Input_lastName),
                Enter.theValue(emailAddress).into(SignutPerson.Input_Email),
                Enter.theValue(month).into(SignutPerson.Input_Month),
                Enter.theValue(day).into(SignutPerson.Input_Day),
                Enter.theValue(year).into(SignutPerson.Input_year),
                Click.on(SignutPerson.NextLocation)
        );
    }
}

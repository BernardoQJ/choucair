package co.com.choucair.certification.proyectobase.userinterface;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
@DefaultUrl ("https://utest.com")
public class ChoucairAcademyPage extends PageObject {
}
